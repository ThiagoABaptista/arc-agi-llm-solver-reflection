# ARC-AGI-1 Solver - Nível 3

**Autor:** Thiago Aschebrock Baptista  
**Modelo utilizado:** `gemini-3.5-flash-lite`

## Estrutura do Projeto
- `solver/`: Código-fonte em Python contendo o cliente LLM (`llm_client.py`), gerenciador de prompts (`prompt_manager.py`), executor isolado e seguro (`code_executor.py`), e o orquestrador principal (`main.py`).
- `resultados/`: Resumos consolidados em JSON das execuções (Fim a Fim, Geração de Código Simples e Reflexão Iterativa).
- `relatorio.pdf`: Relatório final compilado no formato IJCAI (2 páginas).

## Como Executar

### 1. Instalação e Ambiente
Certifique-se de ter o `uv` instalado e a variável `GOOGLE_API_KEY` configurada no arquivo `.env`.

### 2. Abordagem A: Fim a Fim (End-to-End)
```powershell
uv run --active solver/main.py tarefas/tarefas.txt --mode end-to-end --provider google --model gemini-3.5-flash-lite --label fim_a_fim
```

### 3. Abordagem B: Geração de Código (Code Generation)
```powershell
uv run --active solver/main.py tarefas/tarefas.txt --mode code-execution --provider google --model gemini-3.5-flash-lite --label geracao_codigo
```

### 4. Abordagem C: Geração de Código com Reflexão e Pass@k (Nível 3)
```powershell
uv run --active solver/main.py tarefas/tarefas.txt --mode reflection --provider google --model gemini-3.5-flash-lite --samples 3 --temperature 0.2 --label reflexao
```
